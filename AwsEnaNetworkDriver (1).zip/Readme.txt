AWS ENA Network Driver
======================
AWS Elastic Network Adapter driver enables enhanced networking on EC2
Windows instances. For detailed information on enabling ENA on EC2 Windows
instances, please refer to the documentation at
https://docs.aws.amazon.com/AWSEC2/latest/WindowsGuide/enhanced-networking-ena.html

Version
=======
Current ENA network driver version is 2.9.0.0.

Installation
============
Run the install.ps1 script to install the ENA driver.

Verify the Installation
========================
Once ENA driver is installed and enabled, double click the Network adapters in
the Device Manager and look at the Driver tab to verify the version.
